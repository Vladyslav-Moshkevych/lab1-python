import cowsay

def say_with_cow():
    message = input("Введіть коротке повідомлення: ").strip() or "Hello from Python!"
    cowsay.cow(message[:120])