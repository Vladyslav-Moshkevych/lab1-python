from rich.console import Console
from rich.panel import Panel

def show_welcome():
    console = Console()
    console.print(Panel.fit("[bold cyan]Лабораторна робота №4[/bold cyan]\\n[green]Знайомство з бібліотеками Python[/green]",
                            title="Python Helper"))