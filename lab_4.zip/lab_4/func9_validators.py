import validators

def validate_user_input():
    url = input("Введіть URL для перевірки (наприклад, https://example.com): ").strip()
    email = input("Введіть електронну пошту для перевірки: ").strip()
    print(f"URL коректний: {'так' if validators.url(url) else 'ні'}")
    print(f"Email коректний: {'так' if validators.email(email) else 'ні'}")