import emoji

def show_emoji_message():
    message = emoji.emojize("Вітаю! :rocket: Python відкриває багато можливостей :snake:", language="alias")
    print(message)