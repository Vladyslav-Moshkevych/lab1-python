from datetime import date
from dateutil.relativedelta import relativedelta

def date_calculator():
    raw = input("Введіть кількість місяців від сьогодні (можна від'ємне число): ").strip()
    try:
        months = int(raw)
        result = date.today() + relativedelta(months=months)
        print(f"Дата через {months} місяців: {result.strftime('%d.%m.%Y')}")
    except ValueError:
        print("Потрібно ввести ціле число.")