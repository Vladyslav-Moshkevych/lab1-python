import math

def calculate_square_root():
    raw = input("Введіть невід'ємне число: ").strip()
    try:
        number = float(raw)
        if number < 0:
            print("Для дійсного квадратного кореня число має бути невід'ємним.")
        else:
            print(f"Квадратний корінь із {number:g} дорівнює {math.sqrt(number):g}")
    except ValueError:
        print("Потрібно ввести число.")