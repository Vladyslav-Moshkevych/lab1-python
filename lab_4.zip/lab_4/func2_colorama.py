from colorama import Fore, Style

def show_colored_message():
    print(Fore.GREEN + Style.BRIGHT + "Це повідомлення надруковане зеленим кольором!")
    print(Fore.YELLOW + "Colorama допомагає додавати кольори до консольного тексту.")