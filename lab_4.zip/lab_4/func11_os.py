import os

def show_current_folder():
    print(f"Поточна робоча папка: {os.getcwd()}")
    print("Файли та папки в ній:")
    try:
        for item in os.listdir("."):
            print(" -", item)
    except OSError as error:
        print(f"Не вдалося прочитати папку: {error}")