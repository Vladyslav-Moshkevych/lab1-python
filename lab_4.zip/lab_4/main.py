from colorama import init, Fore, Style
from rich.console import Console
from rich.panel import Panel
from func1_requests import check_website
from func2_colorama import show_colored_message
from func3_rich import show_welcome
from func4_tabulate import show_library_table
from func5_dateutil import date_calculator
from func6_pyfiglet import show_banner
from func7_emoji import show_emoji_message
from func8_humanize import show_humanized_values
from func9_validators import validate_user_input
from func10_cowsay import say_with_cow
from func11_os import show_current_folder
from func12_random import generate_number
from func13_math import calculate_square_root
from func14_datetime import show_current_datetime
from func15_json import save_and_read_json

init(autoreset=True)
console = Console()

def main():
    show_welcome()
    while True:
        print(Fore.CYAN + """
========== ГОЛОВНЕ МЕНЮ ==========
1. Перевірити доступність вебсайту (requests)
2. Кольорове повідомлення (colorama)
3. Показати таблицю бібліотек (tabulate)
4. Обчислити дату через dateutil
5. Створити текстовий банер (pyfiglet)
6. Показати повідомлення з емодзі (emoji)
7. Людинозрозумілий формат чисел/часу (humanize)
8. Перевірити URL та електронну пошту (validators)
9. Вивести повідомлення від корови (cowsay)
10. Показати поточну папку (os)
11. Згенерувати випадкове число (random)
12. Обчислити квадратний корінь (math)
13. Показати дату й час (datetime)
14. Зберегти та прочитати JSON (json)
0. Вихід
==================================
""")
        choice = input("Оберіть дію: ").strip()
        if choice == "1":
            check_website()
        elif choice == "2":
            show_colored_message()
        elif choice == "3":
            show_library_table()
        elif choice == "4":
            date_calculator()
        elif choice == "5":
            show_banner()
        elif choice == "6":
            show_emoji_message()
        elif choice == "7":
            show_humanized_values()
        elif choice == "8":
            validate_user_input()
        elif choice == "9":
            say_with_cow()
        elif choice == "10":
            show_current_folder()
        elif choice == "11":
            print(f"Випадкове число від 1 до 100: {generate_number()}")
        elif choice == "12":
            calculate_square_root()
        elif choice == "13":
            show_current_datetime()
        elif choice == "14":
            save_and_read_json()
        elif choice == "0":
            print("До побачення!")
            break
        else:
            print(Fore.RED + "Невірний пункт меню. Спробуйте ще раз.")
        input("Натисніть Enter, щоб повернутися до меню...")

if __name__ == "__main__":
    main()