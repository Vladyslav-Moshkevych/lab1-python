from datetime import datetime

def show_current_datetime():
    now = datetime.now()
    print("Поточні дата й час:", now.strftime("%d.%m.%Y %H:%M:%S"))