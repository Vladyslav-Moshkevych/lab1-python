import humanize
from datetime import datetime, timedelta

def show_humanized_values():
    number = 1250000
    past = datetime.now() - timedelta(days=3, hours=4)
    print(f"Число {number} у зручному форматі: {humanize.intcomma(number)}")
    print(f"Приблизний час від події: {humanize.naturaltime(past)}")