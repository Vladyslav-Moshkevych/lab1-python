import json
from pathlib import Path

def save_and_read_json():
    data = {
        "project": "Lab4",
        "purpose": "Демонстрація бібліотек Python",
        "status": "готово"
    }
    file_path = Path("lab4_data.json")
    try:
        file_path.write_text(json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8")
        loaded_data = json.loads(file_path.read_text(encoding="utf-8"))
        print(f"Дані збережено у файл {file_path.resolve()}")
        print("Прочитані дані:")
        print(json.dumps(loaded_data, ensure_ascii=False, indent=4))
    except OSError as error:
        print(f"Помилка роботи з файлом: {error}")