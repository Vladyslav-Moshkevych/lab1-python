from tabulate import tabulate

def show_library_table():
    rows = [
        ["requests", "HTTP-запити"],
        ["colorama", "Кольори в консолі"],
        ["rich", "Форматований вивід"],
        ["tabulate", "Таблиці"],
        ["python-dateutil", "Робота з датами"],
        ["pyfiglet", "Текстові банери"],
        ["emoji", "Емодзі"],
        ["humanize", "Зручне форматування"],
        ["validators", "Перевірка введення"],
        ["cowsay", "Текстові персонажі"],
    ]
    print(tabulate(rows, headers=["Бібліотека", "Призначення"], tablefmt="grid"))