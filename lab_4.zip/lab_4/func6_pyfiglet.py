import pyfiglet

def show_banner():
    text = input("Введіть короткий текст для банера: ").strip() or "Python"
    print(pyfiglet.figlet_format(text[:20], font="standard"))