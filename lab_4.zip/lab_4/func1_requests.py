import requests

def check_website():
    url = input("Введіть адресу сайту (наприклад, https://example.com): ").strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    try:
        response = requests.get(url, timeout=8)
        print(f"Сайт відповів. HTTP-статус: {response.status_code}")
        print(f"Кінцева адреса: {response.url}")
    except requests.RequestException as error:
        print(f"Не вдалося звернутися до сайту: {error}")